#!/usr/bin/env sh
set -eu
python -m workflow_automation.cli --db ./demo-workflow.sqlite3 --input data/sample_tickets.json
