"""Small, deterministic policy lookup over synthetic public-safe sample content."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Article:
    article_id: str
    title: str
    text: str
    category: str


ARTICLES = [
    Article("KB-101", "Refund policy", "Refund requests must be reviewed against the order terms. Do not promise a refund before eligibility is confirmed. Billing disputes require a human reviewer.", "billing"),
    Article("KB-102", "Account access", "For account lockouts, direct the customer to the official password reset flow. Never request passwords, one-time codes, or full payment credentials.", "account"),
    Article("KB-103", "Technical troubleshooting", "For technical issues, ask for the affected feature, approximate time, and a non-sensitive error message. Do not ask customers to share secrets or private keys.", "technical"),
    Article("KB-104", "Shipping delays", "For a delayed shipment, confirm the order reference through approved internal procedures. Do not guarantee a delivery date unless the carrier has confirmed it.", "shipping"),
    Article("KB-105", "Security and privacy escalation", "Suspected account compromise, exposed credentials, threats, legal requests, or personal-data incidents must be escalated to a human reviewer. Do not make irreversible account changes automatically.", "other"),
]


def retrieve(query: str, limit: int = 3) -> list[Article]:
    terms = {word.lower().strip(".,!?():;\"'") for word in query.split() if len(word) > 2}
    scored: list[tuple[int, Article]] = []
    for article in ARTICLES:
        haystack = f"{article.title} {article.text} {article.category}".lower()
        score = sum(term in haystack for term in terms)
        if score:
            scored.append((score, article))
    scored.sort(key=lambda pair: (-pair[0], pair[1].article_id))
    return [article for _, article in scored[:limit]]
