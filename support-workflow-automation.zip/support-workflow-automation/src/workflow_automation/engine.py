from __future__ import annotations

import re
from dataclasses import replace
from datetime import datetime, timezone

from .knowledge import retrieve
from .models import TicketEvent, TicketRecord, utc_now
from .providers import DraftProvider, MockDraftProvider
from .store import WorkflowStore


SENSITIVE_TERMS = (
    "hacked", "account takeover", "stolen", "legal notice", "lawyer", "lawsuit",
    "data breach", "personal data", "exposed password", "credential leak", "delete my account",
    "chargeback", "fraud", "threat", "self harm", "suicide",
)
HIGH_TERMS = ("urgent", "critical", "cannot access", "locked out", "outage", "charged twice", "missing package")


def classify(subject: str, message: str) -> tuple[str, str, bool]:
    text = f"{subject} {message}".lower()
    sensitive = any(term in text for term in SENSITIVE_TERMS)
    if any(term in text for term in ("refund", "invoice", "billing", "charged", "payment", "chargeback")):
        category = "billing"
    elif any(term in text for term in ("password", "login", "account", "locked out", "hacked")):
        category = "account"
    elif any(term in text for term in ("ship", "delivery", "package", "tracking", "carrier")):
        category = "shipping"
    elif any(term in text for term in ("error", "bug", "crash", "not working", "outage", "technical")):
        category = "technical"
    else:
        category = "other"
    priority = "critical" if sensitive or "outage" in text or "data breach" in text else "high" if any(term in text for term in HIGH_TERMS) else "normal"
    if priority == "normal" and len(message) < 80:
        priority = "low"
    return category, priority, sensitive


class WorkflowEngine:
    def __init__(self, store: WorkflowStore, provider: DraftProvider | None = None, max_attempts: int = 3) -> None:
        self.store = store
        self.provider = provider or MockDraftProvider()
        self.max_attempts = max(1, max_attempts)

    def submit(self, event: TicketEvent) -> tuple[TicketRecord, bool]:
        existing = self.store.get(event.event_id)
        if existing:
            return existing, False
        category, priority, sensitive = classify(event.subject, event.message)
        now = utc_now()
        record = TicketRecord(
            event_id=event.event_id,
            customer_ref=event.customer_ref,
            subject=event.subject,
            message=event.message,
            channel=event.channel,
            category=category,  # type: ignore[arg-type]
            priority=priority,  # type: ignore[arg-type]
            sensitive=sensitive,
            status="received",
            proposed_action="human_review_required" if sensitive else "draft_for_review",
            created_at=now,
            updated_at=now,
        )
        inserted = self.store.insert(record)
        if not inserted:
            # Covers concurrent duplicate submissions protected by the DB primary key.
            return self.store.get(event.event_id) or record, False
        return self.process(event.event_id), True

    def process(self, event_id: str) -> TicketRecord:
        record = self.store.get(event_id)
        if not record:
            raise KeyError(event_id)
        if record.status in ("pending_approval", "completed", "rejected"):
            return record
        record = record.model_copy(update={"status": "processing", "updated_at": utc_now(), "error": None})
        self.store.update(record, "workflow_started")
        for _attempt_in_run in range(self.max_attempts):
            attempt = record.attempts + 1
            try:
                articles = retrieve(f"{record.subject} {record.message} {record.category}")
                response = self.provider.draft(record.subject, record.message, articles)
                # Sensitive requests are always held for human review; nothing is sent externally.
                next_status = "pending_approval" if record.sensitive else "completed"
                proposed_action = "human_review_required" if record.sensitive else "draft_ready_not_sent"
                updated = record.model_copy(update={
                    "status": next_status,
                    "knowledge_refs": [article.article_id for article in articles],
                    "proposed_response": response,
                    "proposed_action": proposed_action,
                    "attempts": attempt,
                    "error": None,
                    "updated_at": utc_now(),
                })
                self.store.update(updated, "draft_created", details={"attempt": attempt, "knowledge_refs": updated.knowledge_refs})
                return updated
            except Exception as exc:  # bounded retries, persisted after every failed attempt
                record = record.model_copy(update={"attempts": attempt, "error": f"{type(exc).__name__}: {exc}", "updated_at": utc_now()})
                self.store.update(record, "attempt_failed", details={"attempt": attempt, "error_type": type(exc).__name__})
        failed = record.model_copy(update={"status": "failed", "updated_at": utc_now(), "proposed_action": "manual_triage_required"})
        self.store.update(failed, "workflow_failed", details={"attempts": failed.attempts})
        return failed

    def retry(self, event_id: str) -> TicketRecord:
        record = self.store.get(event_id)
        if not record:
            raise KeyError(event_id)
        if record.status != "failed":
            return record
        # Resume the persisted workflow without creating a second ticket or audit identity.
        record = record.model_copy(update={"status": "received", "error": None, "updated_at": utc_now()})
        self.store.update(record, "manual_retry_requested", actor="operator")
        return self.process(event_id)

    def review(self, event_id: str, reviewer: str, decision: str, note: str = "") -> TicketRecord:
        record = self.store.get(event_id)
        if not record:
            raise KeyError(event_id)
        if record.status != "pending_approval":
            raise ValueError("Only tickets pending human approval can be reviewed")
        status = "completed" if decision == "approve" else "rejected"
        action = "approved_for_manual_execution_only" if decision == "approve" else "rejected_by_reviewer"
        updated = record.model_copy(update={"status": status, "proposed_action": action, "updated_at": utc_now()})
        self.store.update(updated, "human_review_decision", actor=reviewer, details={"decision": decision, "note": note[:1000]})
        return updated
