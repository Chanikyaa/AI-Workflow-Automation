from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse

from .engine import WorkflowEngine
from .models import ReviewDecision, TicketEvent, TicketRecord
from .providers import MockDraftProvider
from .store import WorkflowStore


def build_engine() -> WorkflowEngine:
    db_path = os.getenv("WORKFLOW_DB_PATH", "./workflow.sqlite3")
    max_attempts = int(os.getenv("WORKFLOW_MAX_ATTEMPTS", "3"))
    return WorkflowEngine(WorkflowStore(db_path), MockDraftProvider(), max_attempts)


engine = build_engine()
app = FastAPI(title="Support Workflow Automation", version="0.1.0", description="Auditable synthetic support-ticket triage with explicit human review.")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "storage": "sqlite"}


@app.post("/api/tickets", response_model=TicketRecord, status_code=201)
def create_ticket(event: TicketEvent) -> TicketRecord:
    record, created = engine.submit(event)
    # Return the same resource on idempotent duplicates. A production deployment could use 200 on duplicate.
    return record


@app.get("/api/tickets", response_model=list[TicketRecord])
def list_tickets(status: str | None = Query(default=None), limit: Annotated[int, Query(ge=1, le=200)] = 100) -> list[TicketRecord]:
    allowed = {"received", "processing", "pending_approval", "completed", "rejected", "failed"}
    if status and status not in allowed:
        raise HTTPException(400, "Unsupported status filter")
    return engine.store.list_tickets(status=status, limit=limit)


@app.get("/api/tickets/{event_id}", response_model=TicketRecord)
def get_ticket(event_id: str) -> TicketRecord:
    record = engine.store.get(event_id)
    if not record:
        raise HTTPException(404, "Ticket not found")
    return record


@app.get("/api/tickets/{event_id}/audit")
def ticket_audit(event_id: str) -> list[dict]:
    if not engine.store.get(event_id):
        raise HTTPException(404, "Ticket not found")
    return engine.store.audit(event_id)


@app.post("/api/tickets/{event_id}/review", response_model=TicketRecord)
def review_ticket(event_id: str, decision: ReviewDecision) -> TicketRecord:
    try:
        return engine.review(event_id, decision.reviewer, decision.decision, decision.note)
    except KeyError:
        raise HTTPException(404, "Ticket not found") from None
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc


@app.post("/api/tickets/{event_id}/retry", response_model=TicketRecord)
def retry_ticket(event_id: str) -> TicketRecord:
    try:
        return engine.retry(event_id)
    except KeyError:
        raise HTTPException(404, "Ticket not found") from None


@app.get("/", response_class=HTMLResponse)
def review_ui() -> str:
    return """<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>Support Workflow Review</title>
<style>body{font:16px system-ui;max-width:1000px;margin:2rem auto;padding:0 1rem;color:#172033}input,textarea,select,button{font:inherit;padding:.55rem;margin:.25rem 0}input,textarea{width:100%;box-sizing:border-box}button{cursor:pointer}article{border:1px solid #ccd2dc;border-radius:10px;padding:1rem;margin:1rem 0}.tag{font-size:.8rem;background:#eef2f7;padding:.2rem .5rem;border-radius:5px}.muted{color:#5b6472}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style></head><body>
<h1>Support workflow review</h1><p class='muted'>Synthetic demo. Drafts are never sent to customers. Sensitive cases require human review.</p>
<h2>Submit ticket</h2><form id='ticketForm'><label>Event ID (idempotency key)<input name='event_id' required value='demo-ticket-001'></label><label>Customer reference<input name='customer_ref' required value='cust-demo-01'></label><label>Subject<input name='subject' required value='Refund request for duplicate charge'></label><label>Message<textarea name='message' required rows='3'>I was charged twice and would like a refund. Please help review this billing issue.</textarea></label><label>Channel<select name='channel'><option>web</option><option>email</option><option>phone</option><option>chat</option></select></label><button>Process ticket</button></form><p id='notice' role='status'></p>
<h2>Tickets</h2><button id='refresh'>Refresh</button><div id='tickets'></div><script>
const el=id=>document.getElementById(id); async function api(url,opts={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...opts});const d=await r.json();if(!r.ok)throw Error(d.detail||r.statusText);return d}
function esc(s){return String(s??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}
async function load(){try{const items=await api('/api/tickets');el('tickets').innerHTML=items.map(t=>`<article><h3>${esc(t.subject)} <span class='tag'>${esc(t.status)}</span></h3><p><b>${esc(t.category)}</b> · priority ${esc(t.priority)} · sensitive ${t.sensitive?'yes':'no'} · attempts ${t.attempts}</p><p>${esc(t.message)}</p><p><b>Evidence:</b> ${esc((t.knowledge_refs||[]).join(', ')||'none')}</p><p><b>Proposed response:</b></p><pre>${esc(t.proposed_response||t.error||'No draft yet')}</pre>${t.status==='pending_approval'?`<button onclick="review('${esc(t.event_id)}','approve')">Approve for manual execution</button> <button onclick="review('${esc(t.event_id)}','reject')">Reject</button>`:''}${t.status==='failed'?`<button onclick="retry('${esc(t.event_id)}')">Retry</button>`:''}<details><summary>Audit trail</summary><pre id='audit-${esc(t.event_id)}'>Loading…</pre><button onclick="audit('${esc(t.event_id)}')">Load audit</button></details></article>`).join('')||'<p>No tickets yet.</p>'}catch(e){el('tickets').textContent=e.message}}
async function review(id,decision){const reviewer=prompt('Reviewer name:');if(!reviewer)return;const note=prompt('Review note (optional):')||'';try{await api('/api/tickets/'+encodeURIComponent(id)+'/review',{method:'POST',body:JSON.stringify({reviewer,decision,note})});await load()}catch(e){alert(e.message)}}
async function retry(id){try{await api('/api/tickets/'+encodeURIComponent(id)+'/retry',{method:'POST'});await load()}catch(e){alert(e.message)}}
async function audit(id){try{el('audit-'+id).textContent=JSON.stringify(await api('/api/tickets/'+encodeURIComponent(id)+'/audit'),null,2)}catch(e){alert(e.message)}}
el('ticketForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target);const body=Object.fromEntries(f.entries());try{const t=await api('/api/tickets',{method:'POST',body:JSON.stringify(body)});el('notice').textContent='Processed '+t.event_id+' — '+t.status;await load()}catch(err){el('notice').textContent=err.message}});el('refresh').onclick=load;load();</script></body></html>"""
