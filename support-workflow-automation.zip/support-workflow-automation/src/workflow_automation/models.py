from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


Category = Literal["billing", "technical", "account", "shipping", "other"]
Priority = Literal["low", "normal", "high", "critical"]
Status = Literal[
    "received", "processing", "pending_approval", "completed", "rejected", "failed"
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class TicketEvent(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    event_id: str = Field(min_length=3, max_length=128, description="Client-provided idempotency key")
    customer_ref: str = Field(min_length=2, max_length=100)
    subject: str = Field(min_length=3, max_length=200)
    message: str = Field(min_length=5, max_length=5000)
    channel: Literal["email", "web", "phone", "chat"] = "web"

    @field_validator("event_id", "customer_ref", "subject", "message")
    @classmethod
    def reject_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must not be blank")
        return value


class TicketRecord(BaseModel):
    event_id: str
    customer_ref: str
    subject: str
    message: str
    channel: str
    category: Category
    priority: Priority
    sensitive: bool
    status: Status
    knowledge_refs: list[str] = Field(default_factory=list)
    proposed_response: str | None = None
    proposed_action: str
    attempts: int = 0
    error: str | None = None
    created_at: str
    updated_at: str


class ReviewDecision(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    reviewer: str = Field(min_length=2, max_length=100)
    decision: Literal["approve", "reject"]
    note: str = Field(default="", max_length=1000)
