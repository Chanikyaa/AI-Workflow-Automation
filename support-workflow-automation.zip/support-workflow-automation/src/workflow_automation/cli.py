from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from .engine import WorkflowEngine
from .models import TicketEvent
from .providers import MockDraftProvider
from .store import WorkflowStore


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a local synthetic support-ticket workflow demo.")
    parser.add_argument("--db", default=os.getenv("WORKFLOW_DB_PATH", "./workflow.sqlite3"))
    parser.add_argument("--input", default="data/sample_tickets.json")
    args = parser.parse_args()
    engine = WorkflowEngine(WorkflowStore(args.db), MockDraftProvider())
    events = json.loads(Path(args.input).read_text(encoding="utf-8"))
    for raw in events:
        ticket, created = engine.submit(TicketEvent.model_validate(raw))
        print(json.dumps({"created": created, **ticket.model_dump()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
