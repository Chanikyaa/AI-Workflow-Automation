from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .models import TicketRecord, utc_now


class WorkflowStore:
    """SQLite-backed state and append-only audit events."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True) if self.db_path != ":memory:" else None
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=10, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS tickets (
                    event_id TEXT PRIMARY KEY,
                    customer_ref TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    message TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    category TEXT NOT NULL,
                    priority TEXT NOT NULL,
                    sensitive INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    knowledge_refs TEXT NOT NULL,
                    proposed_response TEXT,
                    proposed_action TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    details TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(event_id) REFERENCES tickets(event_id)
                );
                CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
                CREATE INDEX IF NOT EXISTS idx_audit_event_id ON audit_events(event_id, id);
            """)

    @staticmethod
    def _row_to_record(row: sqlite3.Row) -> TicketRecord:
        data: dict[str, Any] = dict(row)
        data["sensitive"] = bool(data["sensitive"])
        data["knowledge_refs"] = json.loads(data["knowledge_refs"])
        return TicketRecord.model_validate(data)

    def get(self, event_id: str) -> TicketRecord | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tickets WHERE event_id = ?", (event_id,)).fetchone()
        return self._row_to_record(row) if row else None

    def list_tickets(self, status: str | None = None, limit: int = 100) -> list[TicketRecord]:
        with self._connect() as conn:
            if status:
                rows = conn.execute("SELECT * FROM tickets WHERE status = ? ORDER BY created_at DESC LIMIT ?", (status, limit)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM tickets ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [self._row_to_record(row) for row in rows]

    def insert(self, record: TicketRecord, actor: str = "system") -> bool:
        payload = record.model_dump()
        payload["sensitive"] = int(payload["sensitive"])
        payload["knowledge_refs"] = json.dumps(payload["knowledge_refs"])
        columns = ", ".join(payload.keys())
        placeholders = ", ".join("?" for _ in payload)
        with self._connect() as conn:
            cursor = conn.execute(f"INSERT OR IGNORE INTO tickets ({columns}) VALUES ({placeholders})", tuple(payload.values()))
            if cursor.rowcount:
                conn.execute("INSERT INTO audit_events(event_id,event_type,actor,details,created_at) VALUES(?,?,?,?,?)", (record.event_id, "ticket_received", actor, json.dumps({"status": record.status}), utc_now()))
                return True
            return False

    def update(self, record: TicketRecord, event_type: str, actor: str = "system", details: dict[str, Any] | None = None) -> None:
        payload = record.model_dump()
        payload["sensitive"] = int(payload["sensitive"])
        payload["knowledge_refs"] = json.dumps(payload["knowledge_refs"])
        payload.pop("event_id")
        assignments = ", ".join(f"{key} = ?" for key in payload)
        with self._connect() as conn:
            conn.execute(f"UPDATE tickets SET {assignments} WHERE event_id = ?", (*payload.values(), record.event_id))
            conn.execute("INSERT INTO audit_events(event_id,event_type,actor,details,created_at) VALUES(?,?,?,?,?)", (record.event_id, event_type, actor, json.dumps(details or {}, sort_keys=True), utc_now()))

    def audit(self, event_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT event_type,actor,details,created_at FROM audit_events WHERE event_id = ? ORDER BY id", (event_id,)).fetchall()
        return [{**dict(row), "details": json.loads(row["details"])} for row in rows]
