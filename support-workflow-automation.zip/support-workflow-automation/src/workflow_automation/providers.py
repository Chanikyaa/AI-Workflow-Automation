"""Draft-provider boundary. The default is deterministic and makes no network calls."""
from __future__ import annotations

from typing import Protocol

from .knowledge import Article


class DraftProvider(Protocol):
    def draft(self, subject: str, message: str, articles: list[Article]) -> str: ...


class MockDraftProvider:
    """Predictable local provider; output is a proposal, never sent to a customer."""

    def __init__(self, fail_first: int = 0) -> None:
        self.fail_first = fail_first
        self.calls = 0

    def draft(self, subject: str, message: str, articles: list[Article]) -> str:
        self.calls += 1
        if self.calls <= self.fail_first:
            raise RuntimeError("simulated transient draft-provider failure")
        reference = articles[0].title if articles else "the relevant support procedure"
        return (
            f"Thanks for contacting support about '{subject}'. We understand the issue and will "
            f"review it using {reference.lower()}. Please do not include passwords, one-time codes, "
            "or other sensitive credentials in your reply. A support team member will follow up "
            "if further action is needed."
        )
