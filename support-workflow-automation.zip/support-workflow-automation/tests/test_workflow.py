from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from workflow_automation.api import app
from workflow_automation.engine import WorkflowEngine, classify
from workflow_automation.models import TicketEvent
from workflow_automation.providers import MockDraftProvider
from workflow_automation.store import WorkflowStore


def event(event_id="evt-100", subject="How do I reset my password?", message="I cannot log in to my account and need help."):
    return TicketEvent(event_id=event_id, customer_ref="cust-01", subject=subject, message=message, channel="web")


def test_ticket_validation_rejects_malformed_input():
    with pytest.raises(ValidationError):
        TicketEvent(event_id="x", customer_ref="", subject="a", message="b", unexpected="nope")


def test_duplicate_event_is_idempotent(make_engine):
    engine = make_engine()
    first, created = engine.submit(event())
    second, created_again = engine.submit(event())
    assert created is True
    assert created_again is False
    assert first.event_id == second.event_id
    assert len(engine.store.list_tickets()) == 1
    assert len(engine.store.audit(first.event_id)) >= 3


def test_sensitive_ticket_is_held_for_human_review(make_engine):
    engine = make_engine()
    ticket, _ = engine.submit(event("evt-sensitive", "Possible account compromise", "My account was hacked and there is a suspicious login."))
    assert ticket.sensitive is True
    assert ticket.status == "pending_approval"
    assert ticket.proposed_action == "human_review_required"
    assert ticket.proposed_response


def test_review_requires_pending_approval(make_engine):
    engine = make_engine()
    ticket, _ = engine.submit(event())
    with pytest.raises(ValueError, match="Only tickets pending"):
        engine.review(ticket.event_id, "Reviewer One", "approve")


def test_approval_is_audited_and_does_not_send_external_action(make_engine):
    engine = make_engine()
    ticket, _ = engine.submit(event("evt-risk", "Account hacked", "My account was hacked; please help immediately."))
    reviewed = engine.review(ticket.event_id, "Reviewer One", "approve", "Verified manually")
    assert reviewed.status == "completed"
    assert reviewed.proposed_action == "approved_for_manual_execution_only"
    audit = engine.store.audit(ticket.event_id)
    assert audit[-1]["event_type"] == "human_review_decision"
    assert audit[-1]["actor"] == "Reviewer One"


def test_retries_transient_provider_failure(make_engine):
    provider = MockDraftProvider(fail_first=1)
    engine = make_engine(provider=provider)
    ticket, _ = engine.submit(event("evt-retry"))
    assert ticket.status == "completed"
    assert ticket.attempts == 2
    audit_types = [item["event_type"] for item in engine.store.audit(ticket.event_id)]
    assert "attempt_failed" in audit_types
    assert "draft_created" in audit_types


def test_failed_workflow_can_be_retried_after_provider_recovers(make_engine):
    provider = MockDraftProvider(fail_first=99)
    engine = make_engine(provider=provider, max_attempts=2)
    ticket, _ = engine.submit(event("evt-recover"))
    assert ticket.status == "failed"
    provider.fail_first = provider.calls  # next call succeeds
    retried = engine.retry(ticket.event_id)
    assert retried.status == "completed"
    assert retried.attempts == 3
    assert any(item["event_type"] == "manual_retry_requested" for item in engine.store.audit(ticket.event_id))


def test_persisted_state_survives_engine_restart(tmp_path):
    db = tmp_path / "persistent.sqlite3"
    first_engine = WorkflowEngine(WorkflowStore(db), MockDraftProvider())
    first, _ = first_engine.submit(event("evt-persist"))
    second_engine = WorkflowEngine(WorkflowStore(db), MockDraftProvider())
    restored = second_engine.store.get("evt-persist")
    assert restored is not None
    assert restored.status == first.status
    assert restored.proposed_response == first.proposed_response


def test_classifier_categories_and_priority():
    assert classify("Duplicate invoice charge", "I was charged twice and need help.")[0] == "billing"
    assert classify("Outage", "The service outage affects our team.")[1] == "critical"


def test_api_health_and_ticket_creation(tmp_path, monkeypatch):
    monkeypatch.setenv("WORKFLOW_DB_PATH", str(tmp_path / "api.sqlite3"))
    # API module owns a global engine; swap it for isolated test storage.
    import workflow_automation.api as api_module
    api_module.engine = WorkflowEngine(WorkflowStore(tmp_path / "api.sqlite3"), MockDraftProvider())
    client = TestClient(app)
    assert client.get("/health").status_code == 200
    response = client.post("/api/tickets", json={
        "event_id": "api-evt-1", "customer_ref": "cust-1", "subject": "Need help with a bug",
        "message": "The feature is not working as expected, could you help troubleshoot?", "channel": "web"
    })
    assert response.status_code == 201
    assert response.json()["event_id"] == "api-evt-1"
    assert client.get("/api/tickets/api-evt-1/audit").status_code == 200
