import pytest

from workflow_automation.engine import WorkflowEngine
from workflow_automation.providers import MockDraftProvider
from workflow_automation.store import WorkflowStore


@pytest.fixture
def make_engine(tmp_path):
    def factory(provider=None, max_attempts=3, db_name="test.sqlite3"):
        return WorkflowEngine(WorkflowStore(tmp_path / db_name), provider or MockDraftProvider(), max_attempts)
    return factory
