# Architecture and data flow

```mermaid
flowchart TD
    A[Ticket event / demo UI] --> B[Pydantic validation]
    B --> C[SQLite idempotency check]
    C --> D[Normalize and classify]
    D --> E[Keyword policy retrieval]
    E --> F[Draft provider adapter]
    F --> G{Sensitive?}
    G -- Yes --> H[Pending human review]
    G -- No --> I[Draft ready; not sent]
    H --> J[Reviewer approve or reject]
    I --> K[SQLite workflow state]
    J --> K
    C --> L[Append-only audit events]
    D --> L
    E --> L
    F --> L
    J --> L
```

## Boundaries

- **API/UI:** accepts events and displays state; no external side-effect integration exists.
- **Engine:** deterministic classification, retrieval, bounded retries, state transitions and review decisions.
- **Knowledge store:** small static synthetic policy set; keyword overlap ranking.
- **Draft provider:** `DraftProvider` protocol; default `MockDraftProvider` makes no network calls.
- **Persistence:** SQLite tables for current ticket state and append-only audit events.

## State machine

`received -> processing -> completed | pending_approval | failed`; human review moves `pending_approval -> completed | rejected`; failed work can be manually retried. Approval means “approved for manual execution only”; no email, account change, refund or other real action is executed.
