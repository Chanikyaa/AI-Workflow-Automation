# Security and operations

## Safety controls

- Synthetic customer references and sample messages only.
- No outbound email, refund, account mutation, or other external action is implemented.
- Potentially sensitive tickets are routed to human review.
- Passwords, one-time codes and secrets are explicitly discouraged in draft language.
- Event payloads are validated and bounded; SQL values use parameters.
- Retries are bounded, persisted, and recorded in the audit trail.
- Duplicate `event_id` submissions reuse the existing workflow record.

## Important limitations

- This is a local portfolio MVP, not a multi-tenant production service.
- There is no authentication, authorization, CSRF protection, tenant isolation, or production-grade rate limiting. Do not expose it publicly without adding these controls.
- The keyword classifier and policy retrieval are intentionally simple; they are not an ML classifier and may misclassify adversarial or ambiguous messages.
- SQLite is appropriate for a local demo, not high-concurrency distributed workers.
- The audit log is append-only through the app API but is not tamper-proof against a database administrator.
- Draft content is deterministic mock output, not a real LLM response.
- Retry behavior is synchronous in-process. There is no distributed queue or automatic worker recovery after a process crash mid-call; persisted records and operator retry support recovery after restart.
- Do not place real customer PII in this demo.

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
export WORKFLOW_DB_PATH=./workflow.sqlite3
uvicorn workflow_automation.api:app --reload
```

Windows PowerShell activation: `.venv\\Scripts\\Activate.ps1`. Open `http://127.0.0.1:8000/` or `/docs`.

## Recovery

1. Inspect `GET /api/tickets?status=failed`.
2. Inspect `GET /api/tickets/{event_id}/audit` to understand failure history.
3. Fix the provider/configuration issue.
4. Use `POST /api/tickets/{event_id}/retry` to retry a failed workflow with the same event identity.
5. Confirm status and audit history. No external action is triggered by retry or approval.
