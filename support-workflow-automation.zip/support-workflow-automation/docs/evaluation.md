# Evaluation plan

The included tests verify input validation, duplicate-event idempotency, classification behavior, sensitive-case routing, auditability, transient retries, persisted state across engine restart, recovery after repeated provider failure, and API smoke behavior.

For a larger evaluation, create a labeled synthetic ticket set and measure:

- Category macro-F1 and per-category precision/recall.
- Priority confusion matrix, emphasizing missed critical tickets.
- Sensitive-case recall (safety-critical; report false negatives explicitly).
- Evidence retrieval Recall@k for expected knowledge-base article IDs.
- Draft policy compliance using a human-reviewed rubric.
- Retry success rate and workflow completion latency.
- Idempotency under repeated and concurrent event delivery.

Do not claim model performance from the deterministic rules or tiny fixtures. Review false negatives manually before changing thresholds. Use only development data to tune rules and retain a held-out test set for final reporting.
