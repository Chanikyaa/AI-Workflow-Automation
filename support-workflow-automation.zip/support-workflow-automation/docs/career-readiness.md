# Career readiness: AI Workflow Automation

## Target roles and skills

AI Engineer, Applied AI Engineer, Generative AI Engineer, Backend/ML Platform Engineer. Demonstrates workflow state machines, API design, structured validation, retrieval, human-in-the-loop safety, persistence, idempotency, bounded retries, audit logging, and test-driven failure handling.

## Requirements-to-implementation map

- Receive event and validate/normalize: `models.py`, `api.py`.
- Classify and prioritize: `engine.py` deterministic rules.
- Retrieve information: `knowledge.py` synthetic policy retrieval.
- Propose response: `providers.py` mock provider interface.
- Human approval: `engine.py` review transition and review UI.
- Persistent state/audit: `store.py` SQLite.
- Duplicate and failed event handling: idempotent primary key and retry method.
- External actions: deliberately not implemented; approval is only a manual-execution authorization state.

## Resume bullet templates (replace placeholders only with measured results)

1. Built a FastAPI support-ticket workflow with SQLite-backed idempotency, bounded retries, and an audit trail; verified **[N]** automated tests.
2. Implemented human-in-the-loop escalation for sensitive cases and prevented unapproved external actions across **[N]** labeled synthetic scenarios.
3. Evaluated ticket routing using category macro-F1, critical-priority recall, and sensitive-case false-negative analysis on a held-out dataset of **[N]** examples.

## Metrics to collect

- Category macro-F1 and per-class confusion matrix.
- Critical and sensitive ticket recall/false-negative counts.
- Retrieval Recall@k for knowledge articles.
- Median and p95 end-to-end latency under defined load.
- Retry recovery rate; duplicate submissions producing one record.
- Human reviewer agreement and average review time.

## Five-minute demo script

1. Open the UI and submit the sample account-access ticket.
2. Show category, priority, policy references and proposed draft.
3. Submit a suspected account compromise; show `pending_approval`.
4. Inspect the audit trail before and after reviewer approval.
5. Repeat the same event ID and demonstrate idempotency.
6. Explain that approval does not send an email or change an account.
7. Run `pytest -q` and show the evaluation plan.

## Two-minute architecture explanation

A FastAPI boundary validates ticket events with Pydantic. A SQLite primary key makes `event_id` the idempotency key. The workflow engine applies deterministic triage rules, retrieves relevant snippets from a small policy corpus, and calls a provider interface to draft a response. Every transition and retry is persisted alongside audit events. Sensitive tickets enter a human review state. Approval changes the workflow state to approved-for-manual-execution only; there is no external side effect. The current version is intentionally local and deterministic so failure paths can be tested without paid APIs.

## Interview questions and answers

1. **Why use a workflow engine instead of one LLM prompt?** Explicit states, retries, approvals and audit records are easier to test and reason about than hidden multi-step behavior inside a single prompt.
2. **What is idempotency?** Repeated delivery of the same event identity does not create a second ticket/workflow. A database primary key enforces the guarantee.
3. **What is the limit of the idempotency implementation?** It deduplicates by `event_id`; it does not detect semantically identical tickets with different IDs.
4. **Why persist state?** It supports inspection and recovery across process restarts, and preserves the audit history.
5. **Why bounded retries?** Retries can recover transient errors but unbounded retries can cause overload or infinite loops.
6. **What should be retried?** Transient provider/timeouts may be retried; invalid input and policy failures generally should not be.
7. **Why human-in-the-loop?** Sensitive or irreversible decisions require accountability and reduce harm from misclassification or generated text.
8. **Does approval send the response?** No. It only marks the proposal approved for manual execution; external action is intentionally absent.
9. **How would you improve classification?** Build a labeled dataset, establish a baseline, compare ML/LLM classifiers, measure per-class errors, and keep a held-out set.
10. **How do you measure safety?** Measure sensitive-case recall and false negatives, inspect cases manually, and test adversarial phrasing.
11. **Why retrieval?** It grounds the draft in relevant policy content and allows evidence references to be audited.
12. **What are retrieval limitations?** Current keyword overlap misses synonyms and semantic relationships; a lexical or vector index can improve it after benchmarking.
13. **Why SQLite?** It is dependency-light and persistent for a local demo; distributed/high-concurrency deployments need stronger storage and transaction design.
14. **Is the audit log immutable?** It is append-only through this application's normal paths, but not tamper-proof against direct database edits.
15. **How should secrets be handled?** Use a secret manager/environment injection, avoid logs, rotate credentials, and least-privilege access; this MVP uses no external credentials.
16. **How would you add a real LLM?** Implement the `DraftProvider` protocol with strict timeouts, redaction, bounded retries, output validation, usage tracking and provider-specific tests.
17. **How do you test provider failures?** Inject a provider that fails the first N calls, assert retry counts, final state and audit records.
18. **What is a race condition risk?** Two simultaneous deliveries could both observe no existing row; the database primary key and `INSERT OR IGNORE` resolve duplicate creation, though processing coordination would need stronger locking for distributed workers.
19. **What would production require?** Authentication, authorization, tenant isolation, a durable job queue, worker leases, observability, rate limits, secure deployment, PII handling and operational alerting.
20. **What happens if the process crashes mid-provider call?** The persisted record remains; operator retry can resume a failed record, but this MVP does not have a queue worker that automatically recovers abandoned `processing` records.

## Debugging/system-design scenarios

1. Duplicate event appears twice: inspect `event_id`, database primary key and concurrent insert path.
2. Provider repeatedly fails: inspect `attempt_failed` events and verify max-attempt configuration; retry after resolving the cause.
3. Sensitive ticket is marked normal: create a labeled regression case, inspect rule ordering, add a test and measure false negatives.
4. Wrong policy snippet retrieved: review token overlap and expected KB IDs; compare retrieval variants on a held-out set.
5. Review endpoint is exposed publicly: disable exposure and add authentication/authorization, CSRF controls and tenant checks before deployment.

## Honest limitations / likely objections

- Rules and retrieval are simple and may fail on paraphrases.
- Mock draft is not evidence of LLM quality.
- No external action connector is implemented by design.
- No auth or multi-tenant controls; not public-deployment ready.
- No distributed queue or crash lease recovery.
