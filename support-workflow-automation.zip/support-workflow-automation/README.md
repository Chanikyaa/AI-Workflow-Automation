# Support Workflow Automation

A small, auditable AI-style workflow for triaging synthetic support tickets. It validates events, classifies category and priority, retrieves policy snippets, drafts a proposed response, routes sensitive cases to human review, and persists workflow state plus an audit trail.

> **Safety boundary:** this project never sends a message, issues a refund, changes an account, or calls an external action API. Reviewer approval only marks a proposal as approved for manual execution.

## Features

- FastAPI API and browser review interface.
- Pydantic input validation and bounded payload lengths.
- Deterministic category/priority triage with sensitive-case escalation.
- Keyword-based retrieval over a tiny synthetic policy knowledge base.
- Replaceable `DraftProvider` interface; default provider is deterministic and offline.
- SQLite persistence, idempotency keyed by `event_id`, append-only application audit events.
- Bounded retries, failure states, manual retry and recovery after restart.
- Human approval/rejection for sensitive tickets.
- Automated tests for malformed input, duplicate events, failure/retry, persistence, review and API behavior.
- Docker, Compose and GitHub Actions CI configuration.

## Architecture

```mermaid
flowchart LR
  A[Ticket event] --> B[Pydantic validation]
  B --> C[Idempotency / SQLite]
  C --> D[Classify and prioritize]
  D --> E[Retrieve policy evidence]
  E --> F[Draft provider]
  F --> G{Sensitive?}
  G -- Yes --> H[Human review]
  G -- No --> I[Draft ready, not sent]
  H --> J[Audit + persistent state]
  I --> J
```

See [architecture](docs/architecture.md), [evaluation plan](docs/evaluation.md), [security and operations](docs/security-and-operations.md), and [career readiness](docs/career-readiness.md).

## Requirements and setup

Python 3.11 or later.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
pytest -q
```

Windows PowerShell: `.venv\\Scripts\\Activate.ps1`.

## Run the API and review UI

```bash
export WORKFLOW_DB_PATH=./workflow.sqlite3
uvicorn workflow_automation.api:app --reload
```

- UI: `http://127.0.0.1:8000/`
- OpenAPI docs: `http://127.0.0.1:8000/docs`
- Health: `http://127.0.0.1:8000/health`

The UI provides a prefilled example. Change the event ID to submit a new event. Reusing the same ID demonstrates idempotency.

## CLI demo

```bash
python -m workflow_automation.cli --db ./demo.sqlite3 --input data/sample_tickets.json
```

The input file contains three synthetic examples. The CLI prints a JSON record per event.

## Example API request

```bash
curl -X POST http://127.0.0.1:8000/api/tickets \
  -H 'Content-Type: application/json' \
  -d '{"event_id":"ticket-2001","customer_ref":"cust-demo-02","subject":"Account may be hacked","message":"I think my account was hacked and I see a suspicious login. Please help.","channel":"web"}'
```

Inspect state and audit trail with `GET /api/tickets/ticket-2001` and `GET /api/tickets/ticket-2001/audit`. For a ticket in `pending_approval`, review with:

```bash
curl -X POST http://127.0.0.1:8000/api/tickets/ticket-2001/review \
  -H 'Content-Type: application/json' \
  -d '{"reviewer":"Demo Reviewer","decision":"approve","note":"Reviewed manually"}'
```

Approval does not send the response or perform any external action.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `WORKFLOW_DB_PATH` | `./workflow.sqlite3` | SQLite state and audit database path |
| `WORKFLOW_MAX_ATTEMPTS` | `3` | Maximum provider attempts per processing run |
| `WORKFLOW_DRAFT_PROVIDER` | `mock` | Reserved configuration label; current API uses the mock provider |

`.env.example` contains placeholders only. The app currently reads environment variables directly; a dotenv dependency is not required.

## Testing and evaluation

Run `pytest -q`. The tests cover malformed input, idempotent duplicate submissions, sensitive-ticket routing, reviewer decisions, audit records, bounded retries, recovery after provider failure, persistence across engine restart, classification and API smoke behavior.

No accuracy or throughput benchmark is claimed. See [evaluation plan](docs/evaluation.md) for a labeled-data plan, including macro-F1, critical-priority recall, sensitive-case false negatives and retrieval Recall@k.

## Docker

```bash
docker compose up --build
```

The SQLite file is stored in a named volume. Docker build/run has not been claimed as verified unless explicitly tested in the current environment.

## Security, privacy and limitations

- Use synthetic examples only; do not add real customer PII.
- No authentication, authorization, CSRF protection, tenant isolation or production rate limiting is implemented. Do not expose publicly.
- Classification and retrieval are deterministic keyword heuristics, not a trained model.
- Draft output is mock text, not a real LLM response.
- SQLite and synchronous retries are for a local demonstration; distributed workers/leases are future work.
- The audit log is not tamper-proof against direct database access.
- A process crash during an in-flight provider call is not automatically recovered by a queue worker; persisted state and operator retry support manual recovery.

## Future improvements

1. Add labeled synthetic data and held-out triage/retrieval evaluation.
2. Implement an optional real provider with timeouts, redaction and output validation.
3. Add authentication, authorization, tenant scoping and audit export.
4. Add a durable queue, worker leases and automatic recovery for stale `processing` states.
5. Compare keyword retrieval with BM25 and embeddings using measured results.

## License

MIT. See `LICENSE`.
